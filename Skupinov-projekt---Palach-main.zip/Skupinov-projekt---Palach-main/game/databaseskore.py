import mysql.connector
from mysql.connector import Error

def uloz_skore(jmeno, skore):
    """ Funkce pro uložení výsledku do MySQL """
    try:
        conn = mysql.connector.connect(
            host='localhost',
            database='tvoje_databaze', # Zde napiš název své DB
            user='root',               # Většinou 'root'
            password=''                # Tvoje heslo (u XAMPP bývá prázdné)
        )
        if conn.is_connected():
            cursor = conn.cursor()
            # SQL příkaz pro vložení dat
            query = "INSERT INTO highscores (player_name, score) VALUES (%s, %s)"
            cursor.execute(query, (jmeno, skore))
            conn.commit()
            print("Skóre bylo úspěšně uloženo do databáze!")
    except Error as e:
        print(f"Chyba při komunikaci s DB: {e}")
    finally:
        if conn.is_connected():
            cursor.close()
            conn.close()

def ziskej_top_skore():
    """ Funkce pro načtení TOP 5 výsledků """
    vysledky = []
    try:
        conn = mysql.connector.connect(host='localhost', database='tvoje_databaze', user='root', password='')
        cursor = conn.cursor()
        cursor.execute("SELECT player_name, score FROM highscores ORDER BY score DESC LIMIT 5")
        vysledky = cursor.fetchall()
    except Error as e:
        print(f"Chyba při načítání žebříčku: {e}")
    finally:
        if conn.is_connected():
            cursor.close()
            conn.close()
    return vysledky
# Skupinov-projekt---Palach

eidam6969 -- Adam Lipš  
Mykashy0 --  Michal Krupka  
tomaskunc08 -- Tomáš Kunc  
warduck7557 -- Oliver Lažo


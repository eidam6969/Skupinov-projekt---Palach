import pygame

black = (0,0,0)
white = (255, 255, 255)
yellow = (255, 255, 0)
red = (255, 0, 0)

screen_width = 800
screen_height = 600

bullet_img = "img/red_dot.png"
player_img = "img/spaceship.png"
invader_img = "img/invader.png"

